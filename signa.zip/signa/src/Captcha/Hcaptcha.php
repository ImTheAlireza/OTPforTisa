<?php

namespace Signa\Captcha;

use Signa\Config\Settings;
use Signa\Log\Logger;

defined( 'ABSPATH' ) || exit;

final class Hcaptcha implements CaptchaProvider, ScriptFallbacks {
	const ENDPOINT = 'https://api.hcaptcha.com/siteverify';
	private $settings;
	private $logger;

	public function __construct( Settings $settings, Logger $logger ) {
		$this->settings = $settings;
		$this->logger   = $logger;
	}

	public function id(): string {
		return 'hcaptcha';
	}

	public function label(): string {
		return __( 'hCaptcha', 'signa' );
	}

	public function scriptUrl(): string {
		return 'https://js.hcaptcha.com/1/api.js?render=explicit&recaptchacompat=off';
	}

	public function fallbackScriptUrls(): array {
		return array( 'https://js.hcaptcha.com/1/api.js' );
	}

	public function clientConfig(): array {
		return array(
			'siteKey' => trim( $this->settings->str( 'captcha_site_key' ) ),
			'kind'    => 'widget',
			'lang'    => str_replace( '_', '-', get_locale() ),
		);
	}

	public function verify( string $token, string $ip ): CaptchaResult {
		$response = wp_remote_post(
			self::ENDPOINT,
			array(
				'timeout' => 10,
				'body'    => array(
					'secret'   => $this->settings->str( 'captcha_secret_key' ),
					'response' => $token,
					'sitekey'  => trim( $this->settings->str( 'captcha_site_key' ) ),
					'remoteip' => $ip,
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			$this->logger->warning( 'captcha.transport_failed', array( 'gateway' => $this->id(), 'error_code' => $response->get_error_code() ) );

			return CaptchaResult::failed( 'captcha_unreachable', __( 'ارتباط با سرویس کپچا برقرار نشد.', 'signa' ) );
		}

		$body = json_decode( (string) wp_remote_retrieve_body( $response ), true );

		if ( ! is_array( $body ) ) {
			return CaptchaResult::failed( 'captcha_bad_response', __( 'پاسخ سرویس کپچا قابل خواندن نیست.', 'signa' ) );
		}

		if ( empty( $body['success'] ) ) {
			$codes = isset( $body['error-codes'] ) ? array_map( 'strval', (array) $body['error-codes'] ) : array();

			$this->logger->notice( 'captcha.rejected', array( 'gateway' => $this->id(), 'reason' => implode( ',', array_slice( $codes, 0, 3 ) ) ) );

			if ( array() !== array_intersect( array( 'invalid-input-secret', 'missing-input-secret', 'sitekey-secret-mismatch', 'invalid-sitekey' ), $codes ) ) {
				return CaptchaResult::failed( 'captcha_misconfigured', __( 'کلیدهای hCaptcha درست نیستند. با مدیر سایت تماس بگیرید.', 'signa' ) );
			}

			if ( array() !== array_intersect( array( 'expired-input-response', 'already-seen-response', 'invalid-or-already-seen-response' ), $codes ) ) {
				return CaptchaResult::failed( 'captcha_expired', __( 'اعتبار کپچا منقضی شده است. لطفاً دوباره تأیید کنید.', 'signa' ) );
			}

			return CaptchaResult::failed( 'captcha_rejected', __( 'کپچا تأیید نشد. لطفاً دوباره تلاش کنید.', 'signa' ) );
		}

		return CaptchaResult::passed();
	}
}
